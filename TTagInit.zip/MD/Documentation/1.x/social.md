<b>/TTagAppSettings/<span class = "ttag-file">social.php</span></b>

```php

<?php 

$ttag_SocialLinks = [
		[
			// Fontawsome class ie. 'fab fa-'
			'className' => FNTAWSM_BRAND,
			// social icon
	  	 	'icon'=>'facebook-f',
	  	 	// Link to the social page.
	  		'link'=> 'https://www.facebook.com/BlazehatTech'
	  	],
		[
			'className' => FNTAWSM_BRAND,
			'icon'=>'twitter',
			'link'=> 'https://twitter.com/BlazehatTech'
		],
		[
			'className' => FNTAWSM_BRAND,
			'icon'=>'youtube',
			'link'=> 'https://www.youtube.com/channel/UCRXchFZDXjW4YQKVsGI75_w'
		],
		[
			'className' => FNTAWSM_BRAND,
			'icon'=>'linkedin',
			'link'=> 'https://www.linkedin.com/company/blazehattech'
		],

	];

```