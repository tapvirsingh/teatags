<?php

return [
			// single link in footer
			'footerLink'=>'ttag-footer-link d-block',
			// collective links on footer.
			'footerLinks'=>'ttag-footer-links col-sm-6',
			'footerHLink'=>'ttag-footer-h-link d-inline-flex m-3',
			'footerSubCap'=>'ttag-footer-sublink-caption',
			// Bootstrap or custom css classes.
			'class' => 'p-5  bg-dark'
	];