<?php

return [
			'name' => 'Tea Tags',
			'link' => 'http://www.blazehattech.com',
			// 'img'  => null,	
			'img'  => 'tea.png',
			// 'imgIcon'  => $brandIcon->get() ,
			'font-family'=>'Dancing Script',
						
		];


