<?php

return [
			// single link in footer
			'footerLink'=>'ttag-footer-link d-block my-1',
			// collective links on footer.
			'footerLinks'=>'ttag-footer-links col-sm-6',
			'footerHLink'=>'ttag-footer-h-link table-cell m-3',
			'footerSubCap'=>'ttag-footer-sublink-caption',

			'horiz-links' => 'col-12 text-center my-2',

			'social-link-class' => 'm-3 text-light d-inline-flex ttag-social-link',
			// Bootstrap or custom css classes.
			'class' => 'p-5  bg-dark',
			'company-class' => 'text-light text-center',

			'icons-class' => 'mr-1',
	];