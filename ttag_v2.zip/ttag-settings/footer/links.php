<?php 

return [
	// 'orien' => 'h', // h = horizontal, v = vertical
	NAVLINKS => ['caption'=>'Navigation','links'=> include ttag_RootSettings('nav-links')],
	'License'=> ['caption'=>'License','links'=>['MIT'=>[
														'ttag-icon' => 'balance-scale',
														'ttag-link'=>	'https://github.com/tapvirsingh/teatags']]],
	// 'Themes' => [
	// 				'caption'=>'Themes',
	// 				'links'=>[
	// 							'Dark' => '#','Light' => '#'
	// 						],
	// 			],
	// BLAZEHATLINKS => ['caption'=>'Blazehat Technologies LLP','links'=>$ttag_BlazehatLinks],
	
];