<?php
return [
	'copyright' => '© Copyright 2020',
	'company' => 'Blazehat Technologies LLP',
	'website' => 'http://blazehattech.com/',
	'social' => [
			'twitter' => 'https://twitter.com/BlazingTeaTags',
			'facebook' => 'https://www.facebook.com/BlazehatTech',
			'linkedin' => 'https://www.linkedin.com/company/blazehattech',
			'youtube'=> 'https://www.youtube.com/channel/UCRXchFZDXjW4YQKVsGI75_w',
		],
];