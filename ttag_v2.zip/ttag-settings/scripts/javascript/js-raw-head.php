<?php
// Scripts in this file will be added in head

return [
	[
		// 'defer' => null,
		'src'=>'https://use.fontawesome.com/982f9975c3.js',
		// 'integrity'=>'sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ',
		// 'crossorigin'=> 'anonymous',
	],
	// [
	// 	'defer' => null,
	// 	'src'=>'https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js',
	// 	'integrity'=>'sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY',
	// 	'crossorigin'=> 'anonymous',
	// ],
];