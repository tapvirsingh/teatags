<?php

// Scripts will be directly embedded in the page.

return [
	'hljs.initHighlightingOnLoad();',
];