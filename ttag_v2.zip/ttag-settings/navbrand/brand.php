<?php

return [
			'name' => 'Tea Tags',
			'link' => 'https://teatags.blazehattechnologies.com/',
			// 'img'  => null,	
			'img'  => 'tea.png',
			// 'imgIcon'  => $brandIcon->get() ,
			'font-family'=>'Dancing Script',
						
		];


