
<p class = "ttag-file">/navbrand/brand.php</p>

It has the settings for brand.

```php
<?php

return [
			// Brand's name
			'name' => 'Tea Tags',

			// Brand's link 
			'link' => 'https://teatags.blazehattechnologies.com/',
	
			// Brand's image.			
			'img'  => 'tea.png',

			// Set the font for displaying brand.
			// The required Google font settings can be set in
			// /ttag-settings/google.php.			
			'font-family'=>'Dancing Script',
		];

```
