<h3 class="display-4 mb-5">Updates</h3>


*Date 28th Oct 2020*

**Directories and files**

1. All uppercase folder and file names have been changed to lowercase.
1. `/TTagAppSettings/` directory has been renamed to `/ttag-settings/`.
2. `/TTagAppSettings/footer.php` has been converted into `/ttag-settings/footer/`
	with following files.
	1. `classes.php`
	2. `configuration.php`
	3. `links.php`


