<p class = "ttag-file">/scripts/javascript/js-raw-head.php</p>

Insert the link details here, if you need to specify `defer`, `src`,`integrity` and `crossorigin`. 

Insert small or single line of javascript scripts here. These scripts will be inserted at the
end of the `<body>` tag.

```php

<?php
// Scripts in this file will be added in head

return [
	[
		'defer' => null,
		'src'=>'',
		'integrity'=>'',
		'crossorigin'=> '',
	],
	[
		'defer' => null,
		'src'=>'',
		'integrity'=>'',
		'crossorigin'=> '',
	],
];

```