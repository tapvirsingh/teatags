<p class = "ttag-file">/scripts/javascript/js-scripts.php</p>

Insert small or single line of javascript scripts here. These scripts will be inserted at the
end of the `<body>` tag.

```php

<?php

// Scripts will be directly embedded in the page.

return [
	'hljs.initHighlightingOnLoad();',
];

```
