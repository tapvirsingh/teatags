<b>/ttag-settings/<span class = "ttag-file">links.php</span></b>


```php
<?php

$ttag_BlazehatLinks = [
 
	'Website' => 'http://blazehattech.com/',
	'Blogs' => 'https://blazehattech.blogspot.com/'

];

```