<p class = "ttag-file">/scripts/javascript/js-links.php</p>

Insert `src` of the script links here. These links will be inserted at the
end of the `<body>` tag.

```php

<?php
// Links to call
return [
	'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js',
	'https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js',
	'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js',
	'//cdnjs.cloudflare.com/ajax/libs/highlight.js/10.1.2/highlight.min.js',
];

```
