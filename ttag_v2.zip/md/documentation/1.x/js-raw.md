<p class = "ttag-file">/scripts/javascript/js-raw.php</p>

Insert the link details here, if you need to specify `src`,`integrity` and `crossorigin`. 

Insert small or single line of javascript scripts here. These scripts will be inserted at the
end of the `<body>` tag.

```php

<?php

// Scripts in this file will be added in body

return [
		[
		'src'=>'',
		'integrity'=>'',
		'crossorigin'=> '',
	],
	[
		'src'=>'',
		'integrity'=>'',
		'crossorigin'=> '',
	],
	[
		'src'=>'',
		'integrity'=>'',
		'crossorigin'=> '',
	],
];

```
