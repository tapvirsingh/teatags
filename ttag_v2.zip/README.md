# Tea Tags
### version 2

PHP view framework that manages complete Html by itself. It uses Bootstrap 4 internally but also allows you to use custom or Bootstrap classes. PHP programmers don't have to embed PHP in HTML, matter of fact they don't have to switch between html and PHP.

For complete documentation refer to the following link.
[https://teatags.blazehattechnologies.com/](https://teatags.blazehattechnologies.com/)