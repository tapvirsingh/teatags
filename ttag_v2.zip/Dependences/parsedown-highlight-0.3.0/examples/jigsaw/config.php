<?php

return [
    'baseUrl' => '',
    'production' => false,
    'collections' => [],
];
