<?php

class Keyword {

	private $code;

	function __construct($code){
		$code = $this->code;
	}

	private function loadKeywords($lang = 'php'){
		
	}

};